// Model1
//Inheritance: Concrete class inheriting from the abstract class VapeModel
public class VapeModel1 extends VapeModel {
    public VapeModel1() {
        super("Model 1", "Classification 1", "Kuringking80", "₱999.99", 80, 4);
    }

    @Override
    public void displayInfo() {
        System.out.println("Model: " + modelName);
        System.out.println("Classification: " + classification);
        System.out.println("Vape Name: " + vapeName);
        System.out.println("Price: " + price);
        System.out.println("Watts: " + watts);
        System.out.println("Cartridge Capacity: " + cartridgeCapacity + "ml");
    }
}