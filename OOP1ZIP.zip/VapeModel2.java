//Model2
public class VapeModel2 extends VapeModel {
    public VapeModel2() {
        super("Model 2", "Classification 2", "Insan30", "₱1200.99", 30, 3);
    }

    @Override
    public void displayInfo() {
        System.out.println("Model: " + modelName);
        System.out.println("Classification: " + classification);
        System.out.println("Vape Name: " + vapeName);
        System.out.println("Price: " + price);
        System.out.println("Watts: " + watts);
        System.out.println("Cartridge Capacity: " + cartridgeCapacity + "ml");
    }
}
