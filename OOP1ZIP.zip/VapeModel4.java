public class VapeModel4 extends VapeModel {
    public VapeModel4() {
        super("Model 4", "Classification 4", "Podpodngipon60", "₱1400.99", 60, 4);
    }

    @Override
    public void displayInfo() {
        System.out.println("Model: " + modelName);
        System.out.println("Classification: " + classification);
        System.out.println("Vape Name: " + vapeName);
        System.out.println("Price: " + price);
        System.out.println("Watts: " + watts);
        System.out.println("Cartridge Capacity: " + cartridgeCapacity + "ml");
    }
}
