// VapeModel.java
    //Abstraction Providing or Creating Structures
    //Impliments the interface
public abstract class VapeModel implements VapeModelInterface {
    protected String modelName;
    protected String classification;
    protected String vapeName;
    protected String price;
    protected int watts;
    protected int cartridgeCapacity;

    //Encapsulate all the datas
    public VapeModel(String modelName, String classification, String vapeName, String price, int watts, int cartridgeCapacity) {
        this.modelName = modelName;
        this.classification = classification;
        this.vapeName = vapeName;
        this.price = price;
        this.watts = watts;
        this.cartridgeCapacity = cartridgeCapacity;
    }

    //Abstract
    public abstract void displayInfo();
}
