//Interface
public interface VapeModelInterface {
    void displayInfo();
}
