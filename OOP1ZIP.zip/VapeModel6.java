public class VapeModel6 extends VapeModel {
    public VapeModel6() {
        super("Model 6", "Classification 6", "Unbroken80", "₱1600.99", 80, 4);
    }

    @Override
    public void displayInfo() {
        System.out.println("Model: " + modelName);
        System.out.println("Classification: " + classification);
        System.out.println("Vape Name: " + vapeName);
        System.out.println("Price: " + price);
        System.out.println("Watts: " + watts);
        System.out.println("Cartridge Capacity: " + cartridgeCapacity + "ml");
    }
}
