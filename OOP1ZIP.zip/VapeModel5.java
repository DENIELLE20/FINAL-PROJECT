public class VapeModel5 extends VapeModel {
    public VapeModel5() {
        super("Model 5", "Classification 5", "Hubakin1200", "₱1500.99", 1200, 6);
    }

    @Override
    public void displayInfo() {
        System.out.println("Model: " + modelName);
        System.out.println("Classification: " + classification);
        System.out.println("Vape Name: " + vapeName);
        System.out.println("Price: " + price);
        System.out.println("Watts: " + watts);
        System.out.println("Cartridge Capacity: " + cartridgeCapacity + "ml");
    }
}
