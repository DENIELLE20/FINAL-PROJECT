import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
//Only for User display
        System.out.print("\n*Welcome to VapeKingdom*");
    
        System.out.println("\n1:Kuringking80:");
        System.out.println("2:Insan30");
        System.out.println("3:Butiti20:");
        System.out.println("4:Podpodngipon60:");
        System.out.println("5:Hubakin1200:");
        System.out.println("6:Unbroken80:");
        System.out.println("7:Rob7000:");

        System.out.println("\nSelect Model:");
        int modelNumber = scanner.nextInt();

        VapeModel vapeModel = createVapeModel(modelNumber);
        
        //POLYMORPHISM
        if (vapeModel != null) {
            vapeModel.displayInfo(); //Polymorphic call
        } else {
            System.out.println("Invalid model number. Please enter a number between 1 and 7.");
        }

        scanner.close();
    }
    //Encapsulation applied
    private static VapeModel createVapeModel(int modelNumber) {
        switch (modelNumber) {
            case 1:
                return new VapeModel1();
            case 2:
                return new VapeModel2();
            case 3:
                return new VapeModel3();
            case 4:
                return new VapeModel4();
            case 5:
                return new VapeModel5();
            case 6:
                return new VapeModel6();
            case 7:
                return new VapeModel7();
            
            default:
                return null;
        }
    }
}
