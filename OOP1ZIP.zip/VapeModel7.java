public class VapeModel7 extends VapeModel {
    public VapeModel7() {
        super("Model 7", "Classification 7", "Rob7000", "₱1700.99", 18, 10);
    }

    @Override
    public void displayInfo() {
        System.out.println("Model: " + modelName);
        System.out.println("Classification: " + classification);
        System.out.println("Vape Name: " + vapeName);
        System.out.println("Price: " + price);
        System.out.println("Watts: " + watts);
        System.out.println("Cartridge Capacity: " + cartridgeCapacity + "ml");
    }
}
