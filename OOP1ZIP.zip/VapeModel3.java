public class VapeModel3 extends VapeModel {
    public VapeModel3() {
        super("Model 3", "Classification 3", "Butiti20", "₱1300.99", 20, 2);
    }

    @Override
    public void displayInfo() {
        System.out.println("Model: " + modelName);
        System.out.println("Classification: " + classification);
        System.out.println("Vape Name: " + vapeName);
        System.out.println("Price: " + price);
        System.out.println("Watts: " + watts);
        System.out.println("Cartridge Capacity: " + cartridgeCapacity + "ml");
    }
}
